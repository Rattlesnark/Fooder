//
//  AppDelegate.h
//  Fooder
//
//  Created by Lucas on 7/11/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


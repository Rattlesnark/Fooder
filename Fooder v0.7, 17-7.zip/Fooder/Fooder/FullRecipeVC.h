//
//  FullRecipeVC.h
//  Fooder
//
//  Created by Lucas on 7/12/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <youtube-ios-player-helper/YTPlayerView.h>

@interface FullRecipeVC : UIViewController

@property (nonatomic) NSString *recipeToLoad; // From previous view - identify which recipe has been selected.

- (IBAction)back:(id)sender;
//- (IBAction)watchVideo:(id)sender;

@property (weak, nonatomic) IBOutlet UILabel *foodLabel;
@property (weak, nonatomic) IBOutlet UILabel *categoryLabel;
@property (weak, nonatomic) IBOutlet UIView *fbShare;

@property(nonatomic, strong) IBOutlet YTPlayerView *playerView;

@end

//
//  FullRecipeVC.m
//  Fooder
//
//  Created by Lucas on 7/12/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import "FullRecipeVC.h"
#import <FBSDKShareKit/FBSDKShareKit.h>

@interface FullRecipeVC ()

@end

@implementation FullRecipeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSLog(@"Trying to view: %@", self.recipeToLoad);
    
    [self loadFBSharing];
    [self getData];
}

-(void)getData {
    self.foodLabel.text = self.recipeToLoad;
    
    [self.playerView loadWithVideoId:@"M7lc1UVf-VE"];
}

-(void)loadFBSharing {
    FBSDKShareLinkContent *content = [[FBSDKShareLinkContent alloc] init];
    content.contentURL = [NSURL URLWithString:@"http://www.facebook.com"];
    content.quote = [NSString stringWithFormat:@"I have learned a new recipe through Fooder! %@", self.foodLabel.text];
    [FBSDKShareDialog showFromViewController:self
                                 withContent:content
                                    delegate:nil];
    
    FBSDKShareButton *button = [[FBSDKShareButton alloc] init];
    button.shareContent = content;
    [self.fbShare addSubview:button];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
- (IBAction)watchVideo:(id)sender {
    [self performSegueWithIdentifier:@"watchVideo" sender:self];
}*/

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
}

// https://developers.google.com/youtube/v3/guides/ios_youtube_helper
// http://stackoverflow.com/questions/12905568/how-do-i-use-uiscrollview-in-storyboard/22489795#22489795
// https://developers.facebook.com/docs/sharing/ios/

@end

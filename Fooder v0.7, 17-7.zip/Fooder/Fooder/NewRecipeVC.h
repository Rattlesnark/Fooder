//
//  NewRecipeVC.h
//  Fooder
//
//  Created by Lucas on 7/12/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewRecipeVC : UIViewController

@end

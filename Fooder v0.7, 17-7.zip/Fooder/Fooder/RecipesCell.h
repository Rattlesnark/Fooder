//
//  RecipesCell.h
//  Fooder
//
//  Created by Lucas on 7/17/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipesCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *recipeCard;
@property (weak, nonatomic) IBOutlet UIImageView *recipeImage;
@property (weak, nonatomic) IBOutlet UILabel *recipeName;
@property (weak, nonatomic) IBOutlet UILabel *recipeCategory;

@end

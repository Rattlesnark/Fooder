//
//  RecipesVC.h
//  Fooder
//
//  Created by Student User on 11/07/2016.
//  Copyright © 2016 Space. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipesVC : UIViewController <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *recipesTable;

@end

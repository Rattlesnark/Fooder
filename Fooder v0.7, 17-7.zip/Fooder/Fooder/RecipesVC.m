//
//  RecipesVC.m
//  Fooder
//
//  Created by Student User on 11/07/2016.
//  Copyright © 2016 Space. All rights reserved.
//

#import "RecipesVC.h"
#import "RecipesCell.h"
#import "FullRecipeVC.h"

@interface RecipesVC () {
    NSArray *testName;
    NSArray *testCategory;
    
    NSString *passRecipe;
}

@end

@implementation RecipesVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self getData];
    
    self.recipesTable.delegate = self;
    self.recipesTable.dataSource = self;
    
    //self.view.backgroundColor = [UIColor colorWithRed:.9 green:.9 blue:.9 alpha:1];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)getData
{
    testName = [[NSArray alloc]initWithObjects:@"Fried Rice", @"Chee Chiong Fan", @"Nasi Lemak", nil];
    testCategory = [[NSArray alloc]initWithObjects:@"First Card", @"Second", @"Third", nil];
    
    //[self.recipesTable reloadData];
    NSLog(@"Loaded data!");
}

//creates cell with a row number (0,1,2, etc), sets the name and description as strings from event object
//from _events
//called after hitting "activate" button, numberOfSectionsInTableView times per event
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RecipesCell *cell = [self.recipesTable dequeueReusableCellWithIdentifier:@"recipeCell"];
    
    // Configure the cell...
    
    if (cell == nil) {
        cell = [[RecipesCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"recipeCell"];
    }
    
    //cell.profileImage.image = [UIImage imageNamed:[photoArray objectAtIndex:indexPath.row]];
    cell.recipeName.text = [testName objectAtIndex:indexPath.row];
    cell.recipeCategory.text = [testCategory objectAtIndex:indexPath.row];
    
    //NSLog([testName objectAtIndex: indexPath.row]);
    
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //return [testName count];
    return 3;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 200.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // selectedIndex = (int)indexPath.row + 1;
    // NSLog(@"ID: %d", selectedIndex); // Track index of UITableView cell selected.
    
    NSLog([testName objectAtIndex:indexPath.row]);
    passRecipe = [testName objectAtIndex:indexPath.row];
    
    [self performSegueWithIdentifier:@"viewRecipe" sender:self];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    FullRecipeVC *fullRecipe = [segue destinationViewController];
    //viewFullFavourite.delegate = self;
    fullRecipe.recipeToLoad = passRecipe;
}

@end

// http://www.appcoda.com/ios-programming-customize-uitableview-storyboard/
// http://www.appcoda.com/customize-table-view-cells-for-uitableview/
// https://medium.com/@cwRichardKim/ios-xcode-tutorial-a-card-based-newsfeed-8bedeb7b8df7#.pl7uoehlt
//
//  SearchTVC.h
//  Fooder
//
//  Created by Lucas on 7/17/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTVC : UITableViewController

@end

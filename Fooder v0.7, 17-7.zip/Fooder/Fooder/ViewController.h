//
//  ViewController.h
//  Fooder
//
//  Created by Lucas on 7/11/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *fbLogin;

// Unused: Login app - perform credential checking.
//- (IBAction)loginButton:(id)sender;

@end


//
//  ViewController.m
//  Fooder
//
//  Created by Lucas on 7/11/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import "ViewController.h"
#import <FBSDKLoginKit/FBSDKLoginKit.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    FBSDKLoginButton *loginButton = [[FBSDKLoginButton alloc] init];
    //loginButton.center = self.view.center;
    //[self.view addSubview:loginButton];
    loginButton.center = self.fbLogin.center;
    [self.view addSubview:loginButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
- (IBAction)loginButton:(id)sender {
    // if login success
    [self performSegueWithIdentifier:@"loginApp" sender:self];
    
    // else pop warning
}*/

// https://developers.facebook.com/docs/ios/

@end

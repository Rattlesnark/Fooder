//
//  WatchRecipeVideo.h
//  Fooder
//
//  Created by Lucas on 7/17/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <youtube-ios-player-helper/YTPlayerView.h>

@interface WatchRecipeVideo : UIViewController

@property(nonatomic, strong) IBOutlet YTPlayerView *playerView;

@end

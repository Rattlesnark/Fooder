//
//  WatchRecipeVideo.m
//  Fooder
//
//  Created by Lucas on 7/17/16.
//  Copyright © 2016 Space. All rights reserved.
//

#import "WatchRecipeVideo.h"

@interface WatchRecipeVideo ()

@end

@implementation WatchRecipeVideo

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.playerView loadWithVideoId:@"M7lc1UVf-VE"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

// https://developers.google.com/youtube/v3/guides/ios_youtube_helper

@end
